const COLORS = {
    white: "#FFFFFF",
    black: "#222222",
    primary: "#FC8143",
    secondary: "#FF4C4C",
    grey: "#CCCCCC"
}

export default COLORS;